import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

public class Parser {

    public void addRecord(Note note) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("storage.txt",true));
            out.write(note.toString());
            out.newLine();
            out.close();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    public ArrayList<Note> initialize() {
        ArrayList<Note> result = new ArrayList<>();
        return result;
    }

//    public static void main(String[] args) {
//        Note note = new Note("EIDI",2.3,6);
//        try {
//            BufferedWriter out = new BufferedWriter(new FileWriter("storage.txt",true));
//            out.write(note.toString());
//            out.newLine();
//            out.close();
//        } catch (Exception e) {
//            System.err.println("Error: " + e.getMessage());
//        }
//    }
}
