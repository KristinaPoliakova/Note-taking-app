public class Note {
    private String title;
    private double grade = 0;
    private int credits;
    private double weight = 1;
    private int semester = 0;

    public String getTitle() {
        return title;
    }

    public double getGrade() {
        return grade;
    }

    public int getCredits() {
        return credits;
    }

    public double getWeight() {
        return weight;
    }

    public int getSemester() {
        return semester;
    }

    public Note (String title, double value, int credits, double weight) {
        this.title = title;
        this.grade = value;
        this.credits = credits;
        this.weight = weight;
    }

    public Note (String title, double value, int credits) {
        this.title = title;
        this.grade = value;
        this.credits = credits;
    }

    @Override
    public String toString () {
        return title + ", grade: " + grade + ", credits: " + credits + ", weight: " + weight;
    }

    public String toStringCustom () {
        String result = title;
        int titleLength = title.length();
        String spacesAfterTitle = CollectionUtil.duplicate("_",15-titleLength);
        result += spacesAfterTitle;
        result += grade;
        int gradeLength = String.valueOf(grade).length();
        String spacesAfterGrade = CollectionUtil.duplicate("_",10-gradeLength);
        result += spacesAfterGrade;
        result += credits;
        int creditsGrade = String.valueOf(credits).length();
        String spacesAfterCredits = CollectionUtil.duplicate("_",12-creditsGrade);
        result += spacesAfterCredits;
        result += weight;
        result += CollectionUtil.duplicate("",3);
        return result;
    }
}
