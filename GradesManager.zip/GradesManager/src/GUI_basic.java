import org.w3c.dom.Text;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Arrays;

/**
 * Ideas:
 *
 * 1. /DONE/ add search field "look for"
 *
 * 2. Search-icon instead of button
 *
 * 3. /DONE/ Remaining credits (настоящие значения, которые релевантны для вычислений)
 *
 * 4.
 */

public class GUI_basic {
    public static void main(String[] args) throws IOException {
        //adding core to main
        Core core = new Core();

        JFrame frame = new JFrame("Basic grades manager"); //creating instance of JFrame (window for our app)

        JLabel averageGradeLabel = new JLabel("Your grade:");
        averageGradeLabel.setBounds(25, 40, 150, 20);

        JLabel avgResult = new JLabel();
        avgResult.setBounds(140, 40, 50,20);

        JLabel totalCreditsLabel = new JLabel("Your credits:");
        totalCreditsLabel.setBounds(25,60,150,20);

        JLabel creditsResult = new JLabel();
        creditsResult.setBounds(140,60,50,20);

        JLabel weightedCredits = new JLabel("Weighted cr.:");
        weightedCredits.setBounds(225,40,120,20);

        JLabel weightedCreditsResult = new JLabel();
        weightedCreditsResult.setBounds(320,40,50,20);


        //initial weighted credits                           легкий костыль
        weightedCreditsResult.setText(core.weightedCredits().replace(".0","") + "/169");

        //initial average Grade (will change after adding new field)
        avgResult.setText(core.average());

        //initial credits
        creditsResult.setText(core.credits() + "/180");

        final TextArea textArea = new TextArea();
        textArea.setBounds(25, 310, 350,250);
        textArea.setEditable(false); //we do not want our user to manipulate the output

        JButton showGradesButton = new JButton("show all"); //creating instance of JButton
        showGradesButton.setBounds(25,260,80, 40);

        ActionListener showGrades = actionEvent -> textArea.setText(core.showAll()); //was: showAll()
        showGradesButton.addActionListener(showGrades);

        JButton searchButton = new JButton("search");

//        JButton searchButton = new JButton();
//        Icon icon = new ImageIcon("search-icon.png");
//        searchButton.setIcon(icon);

        searchButton.setBounds(320,260,60, 43);

        TextField searchRequestField = new TextField();
        searchRequestField.setEditable(true);
        searchRequestField.setBounds(135,260,190,40);

        ActionListener searchButtonIsPressed = actionEvent -> {
            if (searchRequestField.getText() == null || searchRequestField.getText().equals("")) {
                textArea.setText("Error: empty! Please enter your request above");
            } else {
                textArea.setText(core.findCourse(searchRequestField.getText()));
                searchRequestField.setText("");
            }
        };

        searchButton.addActionListener(searchButtonIsPressed);

        JButton addGradeButton = new JButton("add");
        addGradeButton.setBounds(320,212,60, 42);
        addGradeButton.setBackground(Color.green);

        JTextField addGradeField = new JTextField();
        addGradeField.setEditable(true);
        addGradeField.setBounds(133,210,190,42);

        ActionListener addButtonPressed = actionEvent -> {
            if (addGradeField.getText() == null || addGradeField.getText().equals("")) {
                textArea.setText("Error: the add-form is empty!");
            } else {
                String[] data = addGradeField.getText().split(" ");
                //add note to core and display the result in text field
                textArea.setText(core.addNote(data));
                //now update the average grade and total credits panels
                avgResult.setText(core.average());
                creditsResult.setText(core.credits() + "/180");
                weightedCreditsResult.setText(core.weightedCredits().replace(".0","") + "/169");
                addGradeField.setText("");
            }
        };

        addGradeButton.addActionListener(addButtonPressed);

        JButton deleteButton = new JButton("delete");
        deleteButton.setBounds(320,160,60,42);

        JTextField deleteButtonField = new JTextField();
        deleteButtonField.setEditable(true);
        deleteButtonField.setBounds(133,160,190,42);

        ActionListener deleteButtonPressed = actionEvent -> {
            if (deleteButtonField.getText() == null || deleteButtonField.getText().equals("")) {
                textArea.setText("Error: delete-form is empty!");
            } else {
                textArea.setText(core.delete(deleteButtonField.getText()));
                avgResult.setText(core.average());
                creditsResult.setText(core.credits() + "/180");
                weightedCreditsResult.setText(core.weightedCredits().replace(".0","") + "/169");
                deleteButtonField.setText("");

            }
        };

        deleteButton.addActionListener(deleteButtonPressed);

        //Average Grade status
        frame.add(averageGradeLabel);
        frame.add(avgResult);

        //Current credits state status
        frame.add(totalCreditsLabel);
        frame.add(creditsResult);

        //weighted credits
        frame.add(weightedCredits);
        frame.add(weightedCreditsResult);

        //adding button to JFrame
        frame.add(showGradesButton);

        frame.add(addGradeButton);
        frame.add(addGradeField);

        frame.add(searchButton);
        frame.add(searchRequestField);

        frame.add(deleteButton);
        frame.add(deleteButtonField);

        //adding text area to JFrame
        frame.add(textArea);

        frame.setSize(400,650);
        frame.setLayout(null);//using no layout managers
        frame.setVisible(true);//making the frame visible
    }
}
