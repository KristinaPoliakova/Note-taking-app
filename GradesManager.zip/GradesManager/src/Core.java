import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;


/**
 * Ideas:
 * <p>
 * 1. Find a way to decrypt/encrypt storage with password
 * Problems: where to store password to compare with?
 * <p>
 * 2. Add support for multi-user, with login and password
 * <p>
 * 3. Add separate storage for each user (storage_*login*.txt)
 * <p>
 * 4. /DONE/ Edit-function (Should be a little bit tricky in terms of user-friendly design)
 * <p>
 * 5. /DONE/ delete function (should be pretty easy)
 */

//TODO: Search-method for finding a course with its title

public class Core {
    private ArrayList<Note> notes = new ArrayList<>();
    private Calculations calculations = new Calculations();

    public Core() throws IOException {
        init();
    }

    /**
     * Initializes an array from storage.txt
     *
     * @throws IOException
     */

    private void init() throws IOException {
        ArrayList<Note> result = new ArrayList<>();
        try {
            //read the whole file
            File file = new File("storage.txt");
            Scanner scanner = new Scanner(file);
            scanner.useDelimiter("\\Z");

            String data = scanner.next();

            //split the string into line (separate entry for all grades)
            String[] arr = data.split("\n");

            for (String s : arr) {
                notes.add(parseNote(s));
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found: the backup-storage is damage or missing");
        }
    }

    private static Note parseNote(String s) {
        String[] arr = s.split(", ");
        // example of element: EIDI, grade: 3.3, credits: 6, weight: 0.5
        double grade = Double.parseDouble(arr[1].replace("grade: ", ""));
        int credits = Integer.parseInt(arr[2].replace("credits: ", ""));
        double weight = Double.parseDouble(arr[3].replace("weight: ", ""));
        return new Note(arr[0], grade, credits, weight);
    }

    public int backup() throws IOException {
        String info = "";
        for (Note n : notes) {
            info += n.toString() + "\n";
        }
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("storage.txt"));
            out.write(info);
            out.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return 1; //fix for setDefaultCloseAction in swing-GUI -> FIND MORE ELEGANT SOLUTION!
    }

    public String addNote(String[] data) {
        String title = data[0];
        int index = getCourseIndex(title);
        if (data.length == 3) {
            if (index == -1) { // there is no course with such @title
                notes.add(new Note(title, Double.parseDouble(data[1]), Integer.parseInt(data[2])));
            } else {
                notes.remove(index);
                notes.add(index, new Note(title, Double.parseDouble(data[1]), Integer.parseInt(data[2])));
            }
            return showAll();
        } else if (data.length == 4) {
            if (index == -1) {
                notes.add(new Note(title, Double.parseDouble(data[1]), Integer.parseInt(data[2]), Double.parseDouble(data[3])));
            } else {
                notes.remove(index);
                notes.add(index, new Note(title, Double.parseDouble(data[1]), Integer.parseInt(data[2]), Double.parseDouble(data[3])));
            }
            return "Success!";
        } else {
            return "Not enough information!";
        }
    }

    private int getCourseIndex(String title) {
        if (!notes.isEmpty()) {
            int result = -1;
            for (int i = 0; i < notes.size(); i++) {
                if (title.toLowerCase().equals(notes.get(i).getTitle().toLowerCase()))
                    result = i;
            }
            return result;
        } else {
            System.out.println("Error: the grades list is empty");
            return -1;
        }
    }

    public String showAll() {
        String result = "";
        for (Note n : notes) {
            result += n.toString() + "\n";
        }
        return result;
    }

    public String showTableView() {
        String result = "Title" + CollectionUtil.duplicate(" ", 10) + "Grade" +
                CollectionUtil.duplicate(" ", 5) + "Credits" +
                CollectionUtil.duplicate(" ", 5) + "Weight" + "\n\n";
        for (Note n : notes) {
            result += n.toStringCustom() + "\n";
        }
        return result;
    }

    public String average() {
        return String.format("%.3f", calculations.calculateAvg(notes));
    }

    public String credits() {
        return String.valueOf(calculations.totalCredits(notes));
    }

    public String weightedCredits() {
        return String.valueOf(calculations.weighedCredits(notes));
    }

    public String findCourse(String query) {
        int resultIndex = -1;
        for (int i = 0; i < notes.size(); i++) {
            if (notes.get(i).getTitle().toLowerCase().equals(query.toLowerCase())) {
                resultIndex = i;
            }
        }

        if (resultIndex != -1) {
            return notes.get(resultIndex).toString();
        } else {
            return "Error: course with title \'" + query + "\' is not found!\n" + "Try to change your search request.";
        }
    }

    public String delete(String courseTitle) {
        int currentSize = notes.size();
        int sizeBeforeDelete = currentSize;

        for (int i = 0; i < currentSize; i++) {
            if (notes.get(i).getTitle().toLowerCase().equals(courseTitle.toLowerCase())) {
                currentSize -= 1;
                notes.remove(i);
            }
        }

        if (currentSize != sizeBeforeDelete) {
            return showAll();
        } else {
            return "No course with title " + courseTitle + " was found!\n" +
                    "Here is the list of all courses that you have:\n";
            //showAll();
        }
    }

    public void edit(String titleToEdit) {
        if (getCourseIndex(titleToEdit) != -1) {
            System.out.println("In order to edit course \'" + titleToEdit + "\', just use the command \'add\' with the same course title.\n" +
                    "Example: add " + titleToEdit + " grade credits weight(optional)");
        } else {
            System.out.println("Error: there is no course with title \'" + titleToEdit + "\'");
        }
    }

    public void noCommand(String command) {
        if (command.contains(" ")) {
            command = command.substring(0, command.indexOf(" "));
        }
        System.out.println("Error: there is no command \'" + command + "\'\n" +
                "You may use \'help\' instead");
    }
}
