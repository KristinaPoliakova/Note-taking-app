import java.io.IOException;
import java.util.Scanner;

public class ConsoleApp {
    public static void main(String[] args) throws IOException { //only one of many other views
        Core core = new Core();

        Scanner in = new Scanner(System.in);

        System.out.println("Welcome to grades manager!");

        while (true) {
            String input = in.nextLine();
            if (input.startsWith("show")) {
                System.out.print(core.showAll());
            } else if (input.startsWith("ave") || input.equals("avg")) {
                System.out.println(core.average());
            } else if (input.startsWith("add")) {
                String withoutAdd = input.replace("add ","");
                String[] words = withoutAdd.split(" ");
                System.out.println(core.addNote(words));
            } else if (input.equals("credits")) {
                System.out.println(core.credits());
            } else if (input.startsWith("delete ")) {
                String courseToDelete = input.replace("delete ", "");
                core.delete(courseToDelete);
            } else if (input.equals("q") || input.equals("quit")) {
                //backup the changes
                System.out.println("Save changes? y/N");
                String answer = in.nextLine();
                if (answer.toLowerCase().equals("y") || answer.toLowerCase().equals("yes")) {
                    core.backup();
                }
                break;
            } else if (input.startsWith("edit")) {
                if (!input.contains(" ")) {
                    System.out.println("Which course do you want to edit?");
                    String name = in.nextLine();
                    core.edit(name);
                } else {
                    core.edit(input.substring(input.lastIndexOf(" ") + 1));
                }
            } else if (input.toLowerCase().contains("help")) {
                String commands = "show\n" +
                        "avg\n" + "add COURSE GRADE CREDITS WEIGHT?\n" + "credits\n" + "delete COURSE\n" + "edit COURSE?\n" + "q/quit\n";
                System.out.print(commands);
            } else {
                core.noCommand(input);

            }
        }
    }
}
