public class CollectionUtil {

    public static String duplicate(String toDuplicate, int times) {
        String result = "";
        for (int i = 0; i < times; i++) {
            result += toDuplicate;
        }
        return result;
    }
}
