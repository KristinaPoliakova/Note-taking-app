import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class test {

//    public static ArrayList<Note> init() throws IOException {
//        ArrayList<Note> result = new ArrayList<>();
//        try {
//            //read the whole file
//            File file = new File("storage.txt");
//            Scanner scanner = new Scanner(file);
//            scanner.useDelimiter("\\Z");
//
//            String data = scanner.next();
//
//            //split the string into line (separate entry for all grades)
//            String[] arr = data.split("\n");
//
//            for (String s : arr) {
//                result.add(parseNote(s));
//            }
//
//            return result;
//
//        } catch (FileNotFoundException e) {
//            System.out.println("File not found: the backup-storage is damage or missing");
//            return result;
//        }
//    }
//
//    public static Note parseNote(String s) {
//        String[] arr = s.split(", ");
//        // example of element: EIDI, grade: 3.3, credits: 6, weight: 0.5
//        double grade = Double.parseDouble(arr[1].replace("grade: ",""));
//        int credits = Integer.parseInt(arr[2].replace("credits: ",""));
//        double weight = Double.parseDouble(arr[3].replace("weight: ",""));
//        return new Note(arr[0],grade,credits,weight);
//    }
//
//    //changed a little bit, only for test purpose
//    public static void showAll (ArrayList<Note> noten) {
//        for (int i = 0; i < noten.size(); i++) {
//            System.out.println(noten.get(i));
//        }
//    }
//
//    public static void backup(ArrayList<Note> noten) throws IOException{
//        String info = "";
//        for (Note n : noten) {
//            info += n.toString() + "\n";
//        }
//        try {
//            BufferedWriter out = new BufferedWriter(new FileWriter("storage.txt",true));
//            out.write(info);
//            out.close();
//        } catch (IOException e) {
//            System.out.println(e.getMessage());
//        }
//    }



    public static void main(String[] args) throws IOException {
//        showAll(init());
    }
}
