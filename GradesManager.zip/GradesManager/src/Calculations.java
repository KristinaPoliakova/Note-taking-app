import java.util.ArrayList;

public class Calculations {

    public double calculateAvg(ArrayList<Note> notes) {
        double result = 0;
        for (Note n : notes) {
            result += (n.getGrade() * n.getCredits() * n.getWeight());
        }
        return result/weighedCredits(notes);
    }

    public int totalCredits(ArrayList<Note> notes) {
        int result = 0;
        if (!notes.isEmpty()) {
            for (Note n : notes) {
                result += n.getCredits();
            }
        }
        return result;
    }

    public double weighedCredits(ArrayList<Note> notes) {
        double result = 0;
        if (!notes.isEmpty()) {
            for (Note n : notes) {
                result += (n.getCredits() * n.getWeight());
            }
        }
        return result;
    }

}
